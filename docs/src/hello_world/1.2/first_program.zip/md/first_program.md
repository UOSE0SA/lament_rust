# 1.2 first_program.md

> [Back](/course/hello_world/1.2_first_program.md)

```rust
fn main() {
  println!("Hello, world!");
}
```